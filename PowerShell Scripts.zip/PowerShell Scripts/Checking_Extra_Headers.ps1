$excel = New-Object -ComObject excel.application
$WB = $excel.Workbooks.Open('C:\Users\rdutta\Desktop\Rishi\Ataccama\GDM_Index_Constituents-Test.xlsx') 
$WS = $Excel.WorkSheets.item("GDM_Index_Constituents-Test.xls")

$ExtraCol = ($ws.Columns.Find('Des'))
if ($ExtraCol) {$ExtraCol.Delete()}
$wb.Save()
$wb.Close()
$excel.Quit()

