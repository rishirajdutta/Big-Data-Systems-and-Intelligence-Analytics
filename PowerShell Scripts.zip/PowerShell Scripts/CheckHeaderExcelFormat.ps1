﻿#$FilePath = "\\gmo\dev\Opr\Ataccama\Import\EDWOperations\CD_03142019_211546_MTM1.xls"

#$SheetName = "Sheet1"

#Install-Module ImportExcel

# $MinRowValue is the numebr of Title/header rows in the Reports that are not to be considered


Param( $FilePath, $SheetName, [int]$MinRowValue)

$objExcel = New-Object -ComObject Excel.Application

$objExcel.Visible = $false

$WorkBook = $objExcel.Workbooks.Open($FilePath)

$WorkSheet = $WorkBook.sheets.item($SheetName)



#Create an array to store all the Expected Header names that we can loop through to perform check with each corresponding cell in the excel column header.

$array = @('#Ticket','Trade ID','External ID','Counterparty','Class','Currency','Face Amount','Adjusted Face Amount','Buy/Sell','Reference Entity',
'Document Clause','Seniority','Fixed Rate/Coupon','Effective Date','Maturity Date','Maturity Year','Frequency','Basis','Book','Trade Date',
'Business Day','Business Day Convention','Premium Amount','Premium Currency','Premium Percent','Premium Date','Approval Status',
'Position Net PV (Dirty Price) - Mid','Position Net PV (Dirty Price) - Bid','Position Net PV (Dirty Price) - Ask','Position PV (Clean)',
'Accrued','Dirty Price (%)','Clean Price (%)','Market Spread - Mid','Market Spread - Bid','Market Spread - Ask','Market Recovery (%)',
'Bond Equivalent Price','Credit PV01','IR PV01','Credit PV 10%','Loss Given Default','Credit Gamma','Last Reset Date','Next Reset Date',
'Premium Dirty Price','Premium Clean Price','Accrued','PV','Market Value -5% Rate','Market Value +5% Rate')


[int]$ColumnValue = $array.Count;

#  MinRowValue = 5 here since the Column Headers are in 5th row of the excel worksheet


#For loop iterates through all the columns using if condition to check if column header match in excel vs array

for([int]$i = 0; $i -lt $ColumnValue; $i++)
{
 $ColumnHeader = $worksheet.cells.Item($MinRowvalue, $i+1).text;

 If ( $ColumnHeader -eq $array[$i] )
   {
   Write-Host "Header matches:" $ColumnHeader;
   }
   else
   {
   #Write-Host "Header doesn't match:" $ColumnHeader
   $objExcel.Visible = $true
   Exit 1;
   }
}

$objExcel.Visible = $true

Exit 0;