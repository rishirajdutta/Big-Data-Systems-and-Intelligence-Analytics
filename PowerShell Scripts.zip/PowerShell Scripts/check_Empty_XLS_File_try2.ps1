﻿$excel = New-Object -Com Excel.Application
$wb = $excel.Workbooks.Open("C:\Users\rdutta\Desktop\Rishi\Ataccama\test.txt")


if ( (get-childitem $wb).length -eq 0 )
  {
    "sucess"
    }
    {
    "fail"
    }

$excel.Workbook.close()