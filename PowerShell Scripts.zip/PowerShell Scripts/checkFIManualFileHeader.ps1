Param(
  [string]$filePathandName
)

$data = Get-Content $filePathandName
$data[0]

if ($data[0] -eq 'Security_Identifier,Price,Average_Life,Yield_to_Worst,Libor_OA_Duration,Libor_OAD_Exposure,Libor_OA_Spread,Libor_OASD_Risk,Current Support (%),Current Attachment Point,Current Detachment Point,Libor_KRD_6mo,Libor_KRD_2yr,Libor_KRD_5yr,Libor_KRD_10yr,Libor_KRD_20yr,Libor_KRD_30yr,Libor_KRD_6mo_Exposure,Libor_KRD_2yr_Exposure,Libor_KRD_5yr_Exposure,Libor_KRD_10yr_Exposure,Libor_KRD_20yr_Exposure,Libor_KRD_30yr_Exposure,OA_Duration,OAD_Exposure,OA_Spread,OASD_Risk,KRD_6mo,KRD_2yr,KRD_5yr,KRD_10yr,KRD_20yr,KRD_30yr,KRD_6mo_Exposure,KRD_2yr_Exposure,KRD_5yr_Exposure,KRD_10yr_Exposure,KRD_20yr_Exposure,KRD_30yr_Exposure')
{
	Exit 0;
}
else {
    Exit 1;
}



