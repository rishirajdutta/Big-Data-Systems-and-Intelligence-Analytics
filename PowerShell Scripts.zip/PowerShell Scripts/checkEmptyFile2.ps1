#Param( [string]$filePathandName, [int] $lines)


[string]$filePathandName = "\\gmo\dev\Opr\Ataccama\Export\EDWOperations\Temp\EDW_SuperD_Result.csv"
$lines=1

[int]$LinesInFile = 0

$reader = New-Object IO.StreamReader $filePathandName
 
while($reader.ReadLine() -ne $null){ $LinesInFile++ }

$reader.close()
if ($LinesInFile -gt $lines)
{	Exit 0;
}
else {
    Exit 1;
}

