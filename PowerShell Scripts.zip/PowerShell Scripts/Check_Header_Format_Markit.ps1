﻿$FilePath = "\\gmo\dev\Opr\Ataccama\Import\EDWOperations\GMO_NY_DAILY.22Mar19.xls"

$SheetName = "ABSCredIdx"

#Install-Module ImportExcel

# $MinRowValue is the numebr of Title/header rows in the Reports that are not to be considered


#Param( $FilePath, $SheetName, [int]$MinRowValue)

$objExcel = New-Object -ComObject Excel.Application

$objExcel.Visible = $false

$WorkBook = $objExcel.Workbooks.Open($FilePath)

$WorkSheet = $WorkBook.sheets.item($SheetName)



#Create an array to store all the Expected Header names that we can loop through to perform check with each corresponding cell in the excel column header.

$array= @('TradeId', 'Book', 'Notional', 'LocalCcy', 'ValuationCcy', 'Status', 'PVLocal', 'PresentValue', 'Accrued', 'CleanPVLocal', 'CleanPV', 'AccruedValCcy',
             'DirtyPrice', 'CleanPrice', 'PriceAccrued', 'Factor', 'InstrumentCode', 'InstrumentType', 'Abs_Credit01', 'Abs_ParSpread')


$MinRowvalue = 4;

[int]$ColumnValue = $array.Count;

#  MinRowValue = 4 here since the Column Headers are in 5th row of the excel worksheet


#For loop iterates through all the columns using if condition to check if column header match in excel vs array

for([int]$i = 0; $i -lt $ColumnValue; $i++)
{
 $ColumnHeader = $worksheet.cells.Item($MinRowvalue, $i+1).text;

 If ( $ColumnHeader -eq $array[$i] )
   {
   Write-Host "Header matches:" $ColumnHeader;
   }
   else
   {
   Write-Host "Header doesn't match:" $ColumnHeader;
   $objExcel.Visible = $true
   Exit 1;
   }
}
$objExcel.Visible = $true
Exit 0;
