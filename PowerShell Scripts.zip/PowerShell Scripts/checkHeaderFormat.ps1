Param(
  [string]$filePathandName
)

$data = Get-Content $filePathandName
$data[0]

if ($data[0] -eq ' , Des, FIGI, Effective Dt, SEDOL1, ISIN, Cusip (8 Char), Cntry, Crncy, Cpn Rtn, Excess Rtn, Paydown Rtn, Price Rtn, Total Rtn, Currency Rtn, Mty, Years to Mat, Local Yield to Mat, KRD (JPY) 7Y, KRD 6M, KRD 2Y, KRD 5Y, KRD 10Y, KRD 20Y, KRD 30Y, L-OAC, L-OAD, L-OAS, L-OASD, OAD, OAS, OAC, OASD, Yield to Worst, Yield to Mat, Issuer, Accrued Int (%), BCLASS1, BCLASS2, BCLASS3, BCLASS4, Avg Life, DTS, Index Rtg, Idx Rtg Num, Cpn, Cpn Freq, Cpn Type, First Cpn Dt, L-KRD (JPY) 7Y, L-KRD 6M, L-KRD 2Y, L-KRD 5Y, L-KRD 10Y, L-KRD 20Y, L-KRD 30Y, Mkt Val, Market Value (%), Px Close, Z-Spd, I-Spd, G Spd, Idx Flag (HY), Idx Flag (US Agg), Class 4 Code, Class - Broad, Class- Detail, Class - Detail - Code, ID059,	Amt Out, Ticker, Real Mod Dur, Real Yld to Wst, Real Yld to Mty, Real Convex to Mty, OAD Inflation, CPI Type, Breakeven Infl, KRD Infl 10Y, KRD Infl 1Y, KRD Infl 20Y, KRD Infl 2Y, KRD Infl 30Y, KRD Infl 50Y, KRD Infl 5Y, KRD Infl 7Y, Eqty Ticker, Iss Dt, Base CPI, Known CPI')
{
	Exit 0;
}
else {
    Exit 1;
}
