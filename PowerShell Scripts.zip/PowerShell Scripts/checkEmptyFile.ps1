Param( [string]$filePathandName, [int] $lines)


[int]$LinesInFile = 0

$reader = New-Object IO.StreamReader $filePathandName
 
while($reader.ReadLine() -ne $null){ $LinesInFile++ }

$reader.close()
if ($LinesInFile -gt $lines)
{	Exit 0;
}
else {
    Exit 1;
}

