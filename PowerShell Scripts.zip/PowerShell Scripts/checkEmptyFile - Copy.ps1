Param(
  [string]$filePathandName, [int] $lines
)

$data = Get-Content -Length $filePathandName
$data[0]

if ($data[0] > $lines)
{	Exit 0;
}
else {
    Exit 1;
}