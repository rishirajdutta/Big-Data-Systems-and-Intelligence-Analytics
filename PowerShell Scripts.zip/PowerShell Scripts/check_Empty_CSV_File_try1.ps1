﻿ [string]$filePathandName="C:\Users\rdutta\Desktop\Rishi\Ataccama\Copy of abcd.csv"
 [int] $lines


[int]$LinesInFile = 0
$reader = New-Object IO.StreamReader $filePathandName
 while($reader.ReadLine() -ne $null){ $LinesInFile++ }

$reader.close()
if ($LinesInFile > 1)
{	"not empty";
}
else {
    "empty";
}

