﻿
#$APIKey = "uL6uhUzAEC0sMYU4xR/R6G7tac09PTA/3yE5l2UrFkzTiL27b3nOIJip6PtnBIc5KPkWnuPqjPY/Ft2SpZRyPcFvKybcT32vAjWeYG+xt4K+FHG+UGJS4nraXiWrwbfgTqA14hGBxXLyA6V4xQT0fmJsej3uyMVnsXAaO8dfS571zD5L4JsIyOXUUl4P9fwZWvIqw9fPkCqRvPkJDnk9iiqQLbzfapIYY40A2w1H4hVZpC+1zt8+cO4NVnpQugnm83hFAz0IbUAnvNvmbswVQ+PdIgpdW/i0iyIgTmCQLYeU/u3/N4RS1yxcBXR2HxKVI0ZFzhXT7d84vEnAWa6rUQ=="


#$header = @{ "X-Fabric-ApiKey" = $APIKey }

#$WebResponse = Invoke-WebRequest "http://devfabric/api/v2/regions/AttributionUniverse/" -Method Get -Headers $header

#$psversiontable

$source="http://devfabric/api/v2/regions/AttributionUniverse"
$dest="C:\Users\rdutta\Desktop\Rishi\Ataccama\JSON_URL_PARSER\AttributionUniverse.json"
$wc = New-Object System.Net.WebClient
$wc.DownloadFile($source, $dest)