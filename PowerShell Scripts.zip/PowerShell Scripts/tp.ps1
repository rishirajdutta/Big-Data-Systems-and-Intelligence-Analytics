﻿$path = "C:\Users\rdutta\Desktop\Rishi\Ataccama\abcd.xlsx"
import-module psexcel
$people = new-object System.Collections.ArrayList
foreach ($person in (Import-XLSX -Path $path -RowStart 1))
 
{
 
$people.add($person) | out-null #I don't want to see the output
 
}

$people.company | select -unique

$people.Close()