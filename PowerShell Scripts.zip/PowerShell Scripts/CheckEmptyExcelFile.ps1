﻿#$SheetName = "Sheet1"

#Can add one more exit condition if sheet Name has changed

#[int]$MinRowCount = 5 (minimum number of rows file must have)


Param( $FilePath, $SheetName, $MinRowCount)


#Install-Module ImportExcel

$objExcel = New-Object -ComObject Excel.Application

$objExcel.Visible = $false

$WorkBook = $objExcel.Workbooks.Open($FilePath)

$WorkSheet = $WorkBook.sheets.item($SheetName)

$Rowcount = $workSheet.UsedRange.Rows.Count

#Write-Host "RowCount:" $Rowcount

if ( $Rowcount -gt $MinRowCount)
{
#"File is not empty"
  $objExcel.Visible = $true
  Exit 0;
}
Else
{
#"File is empty"
  $objExcel.Visible = $true
  Exit 1;
}





