﻿$excel = New-Object -Com Excel.Application
$wb = $excel.Workbooks.Open("C:\Users\rdutta\Desktop\Rishi\Ataccama\GDM_Index_Constituents-Test.xlsx")




If ((Get-Content $wb ) -eq $Null) 
{     "fail";
}
else {
    "success";
}

$excel.Workbooks.Close()